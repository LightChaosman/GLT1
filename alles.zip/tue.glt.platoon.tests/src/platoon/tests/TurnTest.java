/**
 */
package platoon.tests;

import platoon.Turn;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Turn</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class TurnTest extends StepTest {

	/**
	 * Constructs a new Turn test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TurnTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Turn test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected Turn getFixture() {
		return (Turn)fixture;
	}

} //TurnTest
