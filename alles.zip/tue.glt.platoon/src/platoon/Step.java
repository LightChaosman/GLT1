/**
 */
package platoon;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Step</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see platoon.PlatoonPackage#getStep()
 * @model abstract="true"
 * @generated
 */
public interface Step extends EObject {
} // Step
