/**
 */
package platoon.impl;

import org.eclipse.emf.ecore.EClass;

import platoon.PlatoonPackage;
import platoon.Turn;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Turn</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class TurnImpl extends StepImpl implements Turn {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TurnImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PlatoonPackage.Literals.TURN;
	}

} //TurnImpl
