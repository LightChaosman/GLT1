/**
 */
package platoon.impl;

import org.eclipse.emf.ecore.EClass;

import platoon.PlatoonPackage;
import platoon.TurnLeft;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Turn Left</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class TurnLeftImpl extends TurnImpl implements TurnLeft {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TurnLeftImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PlatoonPackage.Literals.TURN_LEFT;
	}

} //TurnLeftImpl
