/**
 */
package platoon;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Turn Left</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see platoon.PlatoonPackage#getTurnLeft()
 * @model
 * @generated
 */
public interface TurnLeft extends Turn {
} // TurnLeft
