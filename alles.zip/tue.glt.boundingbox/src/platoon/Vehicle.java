/**
 */
package platoon;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Vehicle</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see platoon.PlatoonPackage#getVehicle()
 * @model abstract="true"
 * @generated
 */
public interface Vehicle extends EObject {
} // Vehicle
