/**
 */
package platoon;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Turn Right</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see platoon.PlatoonPackage#getTurnRight()
 * @model
 * @generated
 */
public interface TurnRight extends Turn {
} // TurnRight
