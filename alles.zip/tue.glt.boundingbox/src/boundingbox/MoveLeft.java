/**
 */
package boundingbox;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Move Left</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see boundingbox.BoundingboxPackage#getMoveLeft()
 * @model
 * @generated
 */
public interface MoveLeft extends MoveX {
} // MoveLeft
