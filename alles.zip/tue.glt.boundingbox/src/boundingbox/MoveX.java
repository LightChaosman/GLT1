/**
 */
package boundingbox;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Move X</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see boundingbox.BoundingboxPackage#getMoveX()
 * @model abstract="true"
 * @generated
 */
public interface MoveX extends Move {
} // MoveX
