/**
 */
package boundingbox;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Move Y</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see boundingbox.BoundingboxPackage#getMoveY()
 * @model abstract="true"
 * @generated
 */
public interface MoveY extends Move {
} // MoveY
