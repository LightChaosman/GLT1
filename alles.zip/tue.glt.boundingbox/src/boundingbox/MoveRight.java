/**
 */
package boundingbox;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Move Right</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see boundingbox.BoundingboxPackage#getMoveRight()
 * @model
 * @generated
 */
public interface MoveRight extends MoveX {
} // MoveRight
