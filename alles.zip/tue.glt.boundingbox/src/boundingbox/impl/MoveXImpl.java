/**
 */
package boundingbox.impl;

import boundingbox.BoundingboxPackage;
import boundingbox.MoveX;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Move X</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class MoveXImpl extends MoveImpl implements MoveX {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MoveXImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return BoundingboxPackage.Literals.MOVE_X;
	}

} //MoveXImpl
