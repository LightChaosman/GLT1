/**
 */
package boundingbox.impl;

import boundingbox.BoundingboxPackage;
import boundingbox.MoveY;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Move Y</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class MoveYImpl extends MoveImpl implements MoveY {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MoveYImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return BoundingboxPackage.Literals.MOVE_Y;
	}

} //MoveYImpl
