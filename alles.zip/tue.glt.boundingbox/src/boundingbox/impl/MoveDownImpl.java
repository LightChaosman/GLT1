/**
 */
package boundingbox.impl;

import boundingbox.BoundingboxPackage;
import boundingbox.MoveDown;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Move Down</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class MoveDownImpl extends MoveYImpl implements MoveDown {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MoveDownImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return BoundingboxPackage.Literals.MOVE_DOWN;
	}

} //MoveDownImpl
